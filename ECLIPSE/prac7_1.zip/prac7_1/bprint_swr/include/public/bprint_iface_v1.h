/*
 * bprint_iface_v1.h
 *
 *  Created on: May 16, 2016
 *      Author: user
 */

#ifndef BPRINT_IFACE_V1_H_
#define BPRINT_IFACE_V1_H_

#include <public/bprint.h>

#endif /* BPRINT_IFACE_V1_H_ */
